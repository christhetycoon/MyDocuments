<!-- BEGIN #searchform-->
<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
	<fieldset>
		<input type="text" name="s" id="s" />
	</fieldset>
<!-- END #searchform-->
</form>